# NostalgiaTube v0.1

Klien YouTube untuk Android lama (minSdk 19 / KitKat, juga Nougat dst.), memakai YouTube Data API v3 (API key).
Tanpa dependensi pihak ketiga, UI native (Java + View framework).

Tampilan (Pengaturan > Tampilan):
- Modern: kartu + chip kategori, mirip YouTube sekarang.
- Nostalgia 2008 desktop: grid, tab biru, tautan biru bergaris bawah (hanya tablet & Android TV).
- Nostalgia 2010 mobile: latar gelap, daftar thumbnail di kiri.

## Build (tanpa PC): GitHub Actions
1. Upload folder ini ke repo GitHub (mis. dari Codespaces: `git add . && git commit -m v0.1 && git push`).
2. Tab Actions > "Build APK" > Run workflow (otomatis jalan juga saat push).
3. Setelah hijau, buka run-nya > Artifacts > unduh NostalgiaTube-v0.1-debug-apk > ekstrak > pasang APK.

## API key
console.cloud.google.com > buat project > aktifkan "YouTube Data API v3" > Credentials > Create API key.
Isi di Pengaturan aplikasi. Kuota gratis 10.000 unit/hari: daftar populer = 1 unit, pencarian = ~101 unit.

## Catatan v0.1
- Pemutaran lewat WebView (embed resmi). Di KitKat tanpa pembaruan WebView pemutar bisa gagal; gunakan tombol "Buka di aplikasi / peramban lain".
- Video terkait = pencarian berdasarkan judul (fitur relatedToVideoId sudah dihapus Google).
- Belum ada: login/langganan, komentar, halaman berikutnya (hanya 25-30 video per muat).
