package com.nostalgiatube;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class Api {
    private Api() {}

    private static final String BASE = "https://www.googleapis.com/youtube/v3/";
    private static final String PARTS = "snippet,contentDetails,statistics";

    /** Video terpopuler (biaya kuota: 1). */
    static List<Video> popular(String key, String region, String categoryId) throws Exception {
        String u = BASE + "videos?part=" + PARTS + "&chart=mostPopular&maxResults=30&regionCode=" + region
                + (categoryId != null ? "&videoCategoryId=" + categoryId : "") + "&key=" + key;
        return parse(new JSONObject(Http.get(u)));
    }

    /** Pencarian (biaya kuota: 100 + 1). */
    static List<Video> search(String key, String q, String region) throws Exception {
        String u = BASE + "search?part=snippet&type=video&maxResults=25&regionCode=" + region
                + "&q=" + URLEncoder.encode(q, "UTF-8") + "&key=" + key;
        JSONArray items = new JSONObject(Http.get(u)).optJSONArray("items");
        StringBuilder ids = new StringBuilder();
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject id = items.getJSONObject(i).optJSONObject("id");
                if (id == null) continue;
                String vid = id.optString("videoId", "");
                if (vid.length() == 0) continue;
                if (ids.length() > 0) ids.append(',');
                ids.append(vid);
            }
        }
        if (ids.length() == 0) return new ArrayList<Video>();
        String d = BASE + "videos?part=" + PARTS + "&id=" + ids + "&key=" + key;
        return parse(new JSONObject(Http.get(d)));
    }

    private static List<Video> parse(JSONObject o) throws JSONException {
        List<Video> out = new ArrayList<Video>();
        JSONArray a = o.optJSONArray("items");
        if (a == null) return out;
        for (int i = 0; i < a.length(); i++) {
            JSONObject it = a.getJSONObject(i);
            JSONObject sn = it.optJSONObject("snippet");
            if (sn == null) continue;
            Video v = new Video();
            v.id = it.optString("id", "");
            v.title = sn.optString("title", "");
            v.channel = sn.optString("channelTitle", "");
            v.desc = sn.optString("description", "");
            v.published = Fmt.parseDate(sn.optString("publishedAt", ""));
            v.thumb = thumb(sn.optJSONObject("thumbnails"));
            JSONObject cd = it.optJSONObject("contentDetails");
            if (cd != null) v.duration = Fmt.duration(cd.optString("duration", ""));
            JSONObject st = it.optJSONObject("statistics");
            if (st != null) {
                v.views = st.optLong("viewCount", 0);
                v.likes = st.optLong("likeCount", 0);
            }
            if (v.id.length() > 0) out.add(v);
        }
        return out;
    }

    private static String thumb(JSONObject th) {
        if (th == null) return "";
        String[] order = {"medium", "high", "default"};
        for (String k : order) {
            JSONObject t = th.optJSONObject(k);
            if (t != null && t.optString("url", "").length() > 0) return t.optString("url");
        }
        return "";
    }
}
