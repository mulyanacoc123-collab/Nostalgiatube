package com.nostalgiatube;

import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class Fmt {
    private Fmt() {}

    private static final Pattern DUR = Pattern.compile("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?");

    static String duration(String iso) {
        if (iso == null) return "";
        Matcher x = DUR.matcher(iso);
        if (!x.matches()) return "";
        int h = x.group(1) != null ? Integer.parseInt(x.group(1)) : 0;
        int m = x.group(2) != null ? Integer.parseInt(x.group(2)) : 0;
        int s = x.group(3) != null ? Integer.parseInt(x.group(3)) : 0;
        if (h == 0 && m == 0 && s == 0) return "";
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, s)
                     : String.format(Locale.US, "%d:%02d", m, s);
    }

    static String full(long n) { return String.format(Locale.US, "%,d", n); }

    private static String one(double d) {
        String s = String.format(Locale.US, "%.1f", d);
        if (s.endsWith(".0")) s = s.substring(0, s.length() - 2);
        return s.replace('.', ',');
    }

    static String compact(long n) {
        if (n >= 1000000000L) return one(n / 1e9) + " M";
        if (n >= 1000000L) return one(n / 1e6) + " jt";
        if (n >= 1000L) return one(n / 1e3) + " rb";
        return String.valueOf(n);
    }

    static String ago(long t, boolean en) {
        long d = (System.currentTimeMillis() - t) / 1000;
        if (d < 0) d = 0;
        long[] sec = {31536000L, 2592000L, 86400L, 3600L, 60L};
        String[] enU = {"year", "month", "day", "hour", "minute"};
        String[] idU = {"tahun", "bulan", "hari", "jam", "menit"};
        for (int i = 0; i < sec.length; i++) {
            long n = d / sec[i];
            if (n >= 1) {
                return en ? n + " " + enU[i] + (n > 1 ? "s" : "") + " ago" : n + " " + idU[i] + " lalu";
            }
        }
        return en ? "just now" : "baru saja";
    }

    static long parseDate(String iso) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(iso).getTime();
        } catch (Exception e) {
            return 0;
        }
    }
}
