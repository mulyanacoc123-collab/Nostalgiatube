package com.nostalgiatube;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.widget.ImageView;

/** ImageView dengan sudut membulat (tanpa clipToOutline supaya jalan di KitKat). */
class RImageView extends ImageView {
    private float r;
    private final Path path = new Path();
    private final RectF rect = new RectF();

    RImageView(Context c) { super(c); }

    void setRadius(float r) { this.r = r; }

    @Override protected void onDraw(Canvas c) {
        if (r > 0) {
            rect.set(0, 0, getWidth(), getHeight());
            path.reset();
            path.addRoundRect(rect, r, r, Path.Direction.CW);
            c.clipPath(path);
        }
        super.onDraw(c);
    }
}
