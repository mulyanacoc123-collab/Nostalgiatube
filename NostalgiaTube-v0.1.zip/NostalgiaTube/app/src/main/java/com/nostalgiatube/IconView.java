package com.nostalgiatube;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Ikon sederhana digambar lewat Canvas (tanpa vector drawable, aman untuk KitKat). */
class IconView extends View {
    static final int SEARCH = 0, MORE = 1, CLOSE = 2, BACK = 3, LOGO = 4;
    private final int type, color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    IconView(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
        p.setStrokeCap(Paint.Cap.ROUND);
        if (type != LOGO) {
            setFocusable(true);
            setBackground(U.focusBg(c));
        }
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2, cy = h / 2;
        float s = Math.min(w, h) * 0.5f;
        p.setColor(color);
        p.setStrokeWidth(Math.max(2f, s * 0.14f));
        switch (type) {
            case SEARCH:
                p.setStyle(Paint.Style.STROKE);
                c.drawCircle(cx - s * 0.1f, cy - s * 0.1f, s * 0.34f, p);
                c.drawLine(cx + s * 0.15f, cy + s * 0.15f, cx + s * 0.42f, cy + s * 0.42f, p);
                break;
            case MORE:
                p.setStyle(Paint.Style.FILL);
                for (int k = -1; k <= 1; k++) c.drawCircle(cx, cy + k * s * 0.4f, s * 0.1f, p);
                break;
            case CLOSE:
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx - s * 0.3f, cy - s * 0.3f, cx + s * 0.3f, cy + s * 0.3f, p);
                c.drawLine(cx + s * 0.3f, cy - s * 0.3f, cx - s * 0.3f, cy + s * 0.3f, p);
                break;
            case BACK:
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(cx + s * 0.35f, cy, cx - s * 0.35f, cy, p);
                c.drawLine(cx - s * 0.35f, cy, cx - s * 0.05f, cy - s * 0.3f, p);
                c.drawLine(cx - s * 0.35f, cy, cx - s * 0.05f, cy + s * 0.3f, p);
                break;
            case LOGO: {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFCC0000);
                RectF r = new RectF(0, h * 0.1f, w, h * 0.9f);
                c.drawRoundRect(r, h * 0.28f, h * 0.28f, p);
                p.setColor(0xFFFFFFFF);
                Path t = new Path();
                t.moveTo(cx - w * 0.1f, cy - h * 0.2f);
                t.lineTo(cx + w * 0.14f, cy);
                t.lineTo(cx - w * 0.1f, cy + h * 0.2f);
                t.close();
                c.drawPath(t, p);
                break;
            }
            default:
                break;
        }
    }
}
