package com.nostalgiatube;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

final class Http {
    private Http() {}

    interface Callback<T> { void onResult(T result, Exception error); }

    private static final ExecutorService POOL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static <T> void async(final Callable<T> job, final Callback<T> cb) {
        POOL.execute(new Runnable() {
            @Override public void run() {
                T r = null;
                Exception ex = null;
                try { r = job.call(); } catch (Exception e) { ex = e; }
                final T fr = r;
                final Exception fe = ex;
                MAIN.post(new Runnable() {
                    @Override public void run() { cb.onResult(fr, fe); }
                });
            }
        });
    }

    static String get(String url) throws IOException { return new String(open(url), "UTF-8"); }

    static byte[] getBytes(String url) throws IOException { return open(url); }

    private static byte[] open(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        if (c instanceof HttpsURLConnection && Build.VERSION.SDK_INT < 22) {
            ((HttpsURLConnection) c).setSSLSocketFactory(Tls12.get());
        }
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        byte[] body = in == null ? new byte[0] : readAll(in);
        if (code >= 400) throw new IOException("HTTP " + code + ": " + message(body));
        return body;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close();
        return o.toByteArray();
    }

    private static String message(byte[] body) {
        try {
            return new JSONObject(new String(body, "UTF-8")).getJSONObject("error").getString("message");
        } catch (Exception e) {
            String s;
            try { s = new String(body, "UTF-8"); } catch (Exception e2) { s = ""; }
            return s.length() > 200 ? s.substring(0, 200) : s;
        }
    }
}
