package com.nostalgiatube;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final int MODERN = 0, RETRO2008 = 1, MOBILE2010 = 2;
    private final SharedPreferences sp;

    Prefs(Context c) { sp = c.getSharedPreferences("nt", Context.MODE_PRIVATE); }

    String apiKey() { return sp.getString("key", ""); }
    void setApiKey(String k) { sp.edit().putString("key", k.trim()).apply(); }
    String region() { return sp.getString("region", "ID"); }
    void setRegion(String r) { sp.edit().putString("region", r).apply(); }
    int mode() { return sp.getInt("mode", -1); }
    void setMode(int m) { sp.edit().putInt("mode", m).apply(); }

    /** Mode yang benar-benar dipakai (mode 2008 hanya untuk tablet / Android TV). */
    static int effectiveMode(Context c) {
        int m = new Prefs(c).mode();
        if (m < 0) m = U.isTv(c) ? RETRO2008 : MODERN;
        if (m == RETRO2008 && !U.retroAllowed(c)) m = MODERN;
        return m;
    }
}
