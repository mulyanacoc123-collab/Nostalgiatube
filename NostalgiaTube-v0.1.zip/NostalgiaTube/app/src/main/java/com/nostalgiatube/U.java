package com.nostalgiatube;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.widget.TextView;

final class U {
    private U() {}

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable rect(int color, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable stroke(int fill, int line, float radiusDp, Context c) {
        GradientDrawable g = rect(fill, radiusDp, c);
        g.setStroke(Math.max(1, dp(c, 1)), line);
        return g;
    }

    static Drawable focusBg(Context c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, rect(0x44888888, 24, c));
        s.addState(new int[]{}, new ColorDrawable(0));
        return s;
    }

    static TextView tv(Context c, String t, float sp, int color, boolean bold) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    static int screenDp(Context c) { return c.getResources().getConfiguration().screenWidthDp; }

    static int widthPx(Context c) { return c.getResources().getDisplayMetrics().widthPixels; }

    static boolean isTv(Context c) {
        UiModeManager m = (UiModeManager) c.getSystemService(Context.UI_MODE_SERVICE);
        return m != null && m.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION;
    }

    static boolean retroAllowed(Context c) {
        return isTv(c) || c.getResources().getConfiguration().smallestScreenWidthDp >= 600;
    }
}
