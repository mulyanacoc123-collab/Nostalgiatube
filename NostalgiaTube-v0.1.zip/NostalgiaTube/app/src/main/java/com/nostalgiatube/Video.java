package com.nostalgiatube;

final class Video {
    String id = "", title = "", channel = "", thumb = "", desc = "", duration = "";
    long views, likes, published;
}
