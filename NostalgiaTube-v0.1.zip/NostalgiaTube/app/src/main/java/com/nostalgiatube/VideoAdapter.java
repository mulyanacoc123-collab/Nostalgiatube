package com.nostalgiatube;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.text.Html;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

class VideoAdapter extends BaseAdapter {
    static final int CARD = 0, GRID2008 = 1, ROW2010 = 2, ROW2008 = 3, ROWMOD = 4;
    private static final int[] PALETTE = {0xFFE53935, 0xFF8E24AA, 0xFF3949AB, 0xFF00897B, 0xFFF4511E, 0xFF546E7A};
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Context c;
    private final List<Video> data;
    private final int kind, itemW, padH;
    private final String source;

    private static class H {
        RImageView thumb;
        TextView dur, title, l1, l2, l3, l4, stars, avatar;
    }

    VideoAdapter(Context c, List<Video> data, int kind, int itemW, int padH, String source) {
        this.c = c; this.data = data; this.kind = kind; this.itemW = itemW; this.padH = padH; this.source = source;
    }

    @Override public int getCount() { return data.size(); }
    @Override public Object getItem(int i) { return data.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int i, View cv, ViewGroup parent) {
        H h;
        if (cv == null) {
            h = new H();
            cv = build(h);
            cv.setTag(h);
        } else {
            h = (H) cv.getTag();
        }
        bind(h, data.get(i));
        return cv;
    }

    private int dp(float v) { return U.dp(c, v); }

    private TextView text(float sp, int color, boolean bold, int maxLines) {
        TextView t = U.tv(c, "", sp, color, bold);
        if (maxLines > 0) {
            t.setMaxLines(maxLines);
            t.setEllipsize(TextUtils.TruncateAt.END);
        }
        return t;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private FrameLayout thumbFrame(H h, int w, int ht, float radius, boolean showDur) {
        FrameLayout f = new FrameLayout(c);
        RImageView iv = new RImageView(c);
        iv.setRadius(dp(radius));
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        h.thumb = iv;
        f.addView(iv, new FrameLayout.LayoutParams(w, ht));
        if (showDur) {
            TextView d = U.tv(c, "", 11, Color.WHITE, true);
            d.setPadding(dp(4), dp(1), dp(4), dp(1));
            d.setBackground(U.rect(0xCC000000, radius > 0 ? 4 : 0, c));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.END);
            lp.setMargins(0, 0, dp(6), dp(6));
            f.addView(d, lp);
            h.dur = d;
        }
        return f;
    }

    private View build(H h) {
        switch (kind) {
            case GRID2008: return buildGrid2008(h);
            case ROW2010: return buildRow2010(h);
            case ROW2008: return buildRow2008(h);
            case ROWMOD: return buildRowMod(h);
            default: return buildCard(h);
        }
    }

    // ---- Modern: kartu vertikal seperti YouTube sekarang ----
    private View buildCard(H h) {
        LinearLayout root = vbox();
        root.setPadding(padH, 0, padH, dp(14));
        int tw = itemW - 2 * padH;
        root.addView(thumbFrame(h, tw, tw * 9 / 16, padH > 0 ? 12 : 0, true));
        LinearLayout row = new LinearLayout(c);
        int side = dp(padH > 0 ? 2 : 12);
        row.setPadding(side, dp(10), side, 0);
        h.avatar = U.tv(c, "", 15, Color.WHITE, true);
        h.avatar.setGravity(Gravity.CENTER);
        row.addView(h.avatar, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout col = vbox();
        col.setPadding(dp(12), 0, 0, 0);
        h.title = text(15, 0xFF0F0F0F, false, 2);
        h.l1 = text(12, 0xFF606060, false, 2);
        col.addView(h.title);
        col.addView(h.l1);
        row.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        root.addView(row);
        return root;
    }

    // ---- Modern: baris (daftar terkait di tablet) ----
    private View buildRowMod(H h) {
        LinearLayout row = new LinearLayout(c);
        row.setPadding(dp(12), dp(6), dp(12), dp(6));
        row.addView(thumbFrame(h, dp(168), dp(94), 10, true));
        LinearLayout col = vbox();
        col.setPadding(dp(10), 0, 0, 0);
        h.title = text(14, 0xFF0F0F0F, false, 3);
        h.l1 = text(12, 0xFF606060, false, 3);
        col.addView(h.title);
        col.addView(h.l1);
        row.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        return row;
    }

    // ---- YouTube desktop 2008: sel grid ----
    private View buildGrid2008(H h) {
        LinearLayout root = vbox();
        root.setPadding(dp(8), dp(8), dp(8), dp(8));
        int iw = itemW - dp(16) - dp(2);
        FrameLayout f = thumbFrame(h, iw, iw * 3 / 4, 0, false);
        f.setBackgroundColor(0xFFBDBDBD);
        f.setPadding(dp(1), dp(1), dp(1), dp(1));
        root.addView(f, new LinearLayout.LayoutParams(WRAP, WRAP));
        h.title = text(13, 0xFF0033CC, true, 2);
        h.title.setPaintFlags(h.title.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        h.title.setPadding(0, dp(4), 0, 0);
        h.l1 = text(12, 0xFF000000, true, 1);
        h.l2 = text(11, 0xFF666666, false, 1);
        h.l3 = text(11, 0xFF666666, false, 1);
        h.l4 = text(11, 0xFF666666, false, 1);
        h.stars = text(11, 0xFF666666, false, 1);
        root.addView(h.title);
        root.addView(h.l1);
        root.addView(h.l2);
        root.addView(h.l3);
        root.addView(h.l4);
        root.addView(h.stars);
        return root;
    }

    // ---- YouTube mobile 2010: baris gelap ----
    private View buildRow2010(H h) {
        LinearLayout root = vbox();
        LinearLayout row = new LinearLayout(c);
        row.setPadding(dp(8), dp(8), dp(8), dp(8));
        row.addView(thumbFrame(h, dp(112), dp(84), 0, true));
        LinearLayout col = vbox();
        col.setPadding(dp(10), 0, 0, 0);
        h.title = text(15, Color.WHITE, true, 2);
        h.l1 = text(13, 0xFFBBBBBB, false, 1);
        h.l2 = text(12, 0xFF8A8A8A, false, 1);
        col.addView(h.title);
        col.addView(h.l1);
        col.addView(h.l2);
        row.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        root.addView(row);
        View line = new View(c);
        line.setBackgroundColor(0xFF2E2E2E);
        root.addView(line, new LinearLayout.LayoutParams(MATCH, 1));
        return root;
    }

    // ---- YouTube 2008: baris kecil (video terkait) ----
    private View buildRow2008(H h) {
        LinearLayout root = vbox();
        LinearLayout row = new LinearLayout(c);
        row.setPadding(dp(6), dp(5), dp(6), dp(5));
        FrameLayout f = thumbFrame(h, dp(80), dp(60), 0, false);
        f.setBackgroundColor(0xFFBDBDBD);
        f.setPadding(dp(1), dp(1), dp(1), dp(1));
        row.addView(f);
        LinearLayout col = vbox();
        col.setPadding(dp(8), 0, 0, 0);
        h.title = text(12, 0xFF0033CC, true, 2);
        h.title.setPaintFlags(h.title.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        h.l1 = text(11, 0xFF666666, false, 1);
        h.l2 = text(11, 0xFF666666, false, 1);
        col.addView(h.title);
        col.addView(h.l1);
        col.addView(h.l2);
        row.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        root.addView(row);
        View line = new View(c);
        line.setBackgroundColor(0xFFEEEEEE);
        root.addView(line, new LinearLayout.LayoutParams(MATCH, 1));
        return root;
    }

    private void bind(H h, Video v) {
        ImageLoader.load(h.thumb, v.thumb);
        if (h.dur != null) {
            if (v.duration == null || v.duration.length() == 0) {
                h.dur.setVisibility(View.GONE);
            } else {
                h.dur.setVisibility(View.VISIBLE);
                h.dur.setText(v.duration);
            }
        }
        h.title.setText(v.title);
        String ch = TextUtils.htmlEncode(v.channel);
        switch (kind) {
            case GRID2008:
                h.l1.setText(v.duration);
                h.l2.setText("Added: " + Fmt.ago(v.published, true));
                h.l3.setText(Html.fromHtml("<font color='#666666'>From:</font> <font color='#0033CC'>" + ch + "</font>"));
                h.l4.setText("Views: " + Fmt.full(v.views));
                h.stars.setText(Html.fromHtml("<font color='#CC3333'>\u2605\u2605\u2605\u2605\u2605</font> <font color='#666666'>"
                        + Fmt.full(v.likes) + " likes</font>"));
                break;
            case ROW2010: {
                boolean isNew = System.currentTimeMillis() - v.published < 7L * 86400000L;
                h.l1.setText(Html.fromHtml("by " + ch + (isNew ? " <font color='#FF3333'>New</font>" : "")));
                h.l2.setText("from " + source);
                break;
            }
            case ROW2008:
                h.l1.setText(Html.fromHtml("<b><font color='#000000'>" + v.duration + "</font></b> <font color='#666666'>From:</font> <font color='#0033CC'>" + ch + "</font>"));
                h.l2.setText("Views: " + Fmt.full(v.views));
                break;
            case ROWMOD:
                h.l1.setText(v.channel + "\n" + Fmt.compact(v.views) + " x ditonton \u2022 " + Fmt.ago(v.published, false));
                break;
            default: {
                h.l1.setText(v.channel + " \u2022 " + Fmt.compact(v.views) + " x ditonton \u2022 " + Fmt.ago(v.published, false));
                h.avatar.setText(v.channel.length() > 0 ? v.channel.substring(0, 1).toUpperCase() : "?");
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(PALETTE[Math.abs(v.channel.hashCode() % PALETTE.length)]);
                h.avatar.setBackground(g);
                break;
            }
        }
    }
}
