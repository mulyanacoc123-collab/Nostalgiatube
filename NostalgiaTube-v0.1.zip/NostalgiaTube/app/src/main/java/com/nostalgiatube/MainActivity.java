package com.nostalgiatube;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final String[] CAT_EN = {"Most Popular", "Music", "Gaming", "News", "Sports", "Entertainment"};
    static final String[] CAT_ID = {"Semua", "Musik", "Game", "Berita", "Olahraga", "Hiburan"};
    static final String[] CAT_CODE = {null, "10", "20", "25", "17", "24"};
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // cache sederhana supaya rotasi layar tidak menghabiskan kuota API
    private static String cacheKey;
    private static List<Video> cacheList;

    Prefs p;
    int mode, kind, itemW, padH;
    GridView grid;
    TextView msg, panelTitle, panelCount;
    ProgressBar bar;
    EditText searchBox;
    View titleGroup, searchGroup;
    LinearLayout catRow;
    int catIndex = 0, loadId = 0;
    String query = null;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = new Prefs(this);
        mode = Prefs.effectiveMode(this);
        if (b != null) {
            catIndex = b.getInt("cat", 0);
            query = b.getString("query");
        }
        buildUi();
        if (p.apiKey().length() == 0) showSettings();
        load();
    }

    @Override protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        o.putInt("cat", catIndex);
        o.putString("query", query);
    }

    // ================= UI =================

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(mode == Prefs.MOBILE2010 ? Color.BLACK : Color.WHITE);

        if (mode == Prefs.RETRO2008) root.addView(headerRetro());
        else if (mode == Prefs.MOBILE2010) root.addView(header2010());
        else root.addView(headerModern());

        int wdp = U.screenDp(this);
        int cols;
        int totalW = U.widthPx(this);
        if (mode == Prefs.RETRO2008) {
            kind = VideoAdapter.GRID2008;
            cols = Math.min(6, Math.max(2, wdp / 170));
            totalW -= U.dp(this, 18);
            padH = 0;
        } else if (mode == Prefs.MOBILE2010) {
            kind = VideoAdapter.ROW2010;
            cols = Math.max(1, wdp / 480);
            padH = 0;
        } else {
            kind = VideoAdapter.CARD;
            cols = Math.max(1, wdp / 340);
            padH = cols > 1 ? U.dp(this, 10) : 0;
        }
        itemW = totalW / cols;

        FrameLayout content = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(cols);
        grid.setVerticalSpacing(0);
        grid.setHorizontalSpacing(0);
        grid.setCacheColorHint(0);
        grid.setOnItemClickListener((a, v, pos, id) -> {
            Object o = a.getItemAtPosition(pos);
            if (o instanceof Video) PlayerActivity.open(MainActivity.this, (Video) o);
        });
        content.addView(grid, new FrameLayout.LayoutParams(MATCH, MATCH));

        msg = U.tv(this, "", 14, mode == Prefs.MOBILE2010 ? 0xFFBBBBBB : 0xFF606060, false);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(U.dp(this, 24), U.dp(this, 24), U.dp(this, 24), U.dp(this, 24));
        msg.setVisibility(View.GONE);
        content.addView(msg, new FrameLayout.LayoutParams(MATCH, MATCH));

        bar = new ProgressBar(this);
        bar.setVisibility(View.GONE);
        content.addView(bar, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));

        if (mode == Prefs.RETRO2008) {
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setBackground(U.stroke(0xFFF4F4F4, 0xFFBBBBBB, 0, this));
            LinearLayout head = new LinearLayout(this);
            head.setBackgroundColor(0xFFDDDDDD);
            head.setPadding(U.dp(this, 8), U.dp(this, 6), U.dp(this, 8), U.dp(this, 6));
            panelTitle = U.tv(this, "Most Viewed", 14, Color.BLACK, true);
            panelCount = U.tv(this, "", 12, 0xFF555555, false);
            head.addView(panelTitle, new LinearLayout.LayoutParams(0, WRAP, 1f));
            head.addView(panelCount);
            panel.addView(head);
            panel.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(MATCH, 0, 1f);
            plp.setMargins(U.dp(this, 8), U.dp(this, 4), U.dp(this, 8), U.dp(this, 8));
            root.addView(panel, plp);
        } else {
            root.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        }
        setContentView(root);
    }

    private LinearLayout logoText(int color, float sp) {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER_VERTICAL);
        TextView a = U.tv(this, "Nostalgia", sp, color, true);
        TextView t = U.tv(this, "Tube", sp, Color.WHITE, true);
        t.setBackground(U.rect(0xFFCC0000, 6, this));
        t.setPadding(U.dp(this, 5), 0, U.dp(this, 5), 0);
        l.addView(a);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.setMargins(U.dp(this, 2), 0, 0, 0);
        l.addView(t, lp);
        return l;
    }

    private View spacer() {
        return new View(this) {
            { setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f)); }
        };
    }

    /** Bar atas dengan dua keadaan: judul (titleRow) dan kolom cari. */
    private View headerBar(LinearLayout titleRow, int fg, int hint) {
        FrameLayout f = new FrameLayout(this);
        int h = U.dp(this, 52);
        titleGroup = titleRow;
        f.addView(titleRow, new FrameLayout.LayoutParams(MATCH, h));

        LinearLayout sg = new LinearLayout(this);
        sg.setGravity(Gravity.CENTER_VERTICAL);
        sg.setVisibility(View.GONE);
        searchGroup = sg;
        IconView back = new IconView(this, IconView.BACK, fg);
        back.setOnClickListener(v -> openSearch(false));
        sg.addView(back, new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48)));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextColor(fg);
        searchBox.setHintTextColor(hint);
        searchBox.setHint("Cari");
        searchBox.setBackgroundColor(Color.TRANSPARENT);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setOnEditorActionListener((v, a, e) -> { doSearch(v.getText().toString()); return true; });
        sg.addView(searchBox, new LinearLayout.LayoutParams(0, WRAP, 1f));
        IconView clear = new IconView(this, IconView.CLOSE, fg);
        clear.setOnClickListener(v -> searchBox.setText(""));
        sg.addView(clear, new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48)));
        f.addView(sg, new FrameLayout.LayoutParams(MATCH, h));
        return f;
    }

    private View headerModern() {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(U.dp(this, 12), 0, U.dp(this, 4), 0);
        t.addView(new IconView(this, IconView.LOGO, 0), new LinearLayout.LayoutParams(U.dp(this, 30), U.dp(this, 22)));
        TextView name = U.tv(this, "NostalgiaTube", 20, 0xFF0F0F0F, true);
        name.setPadding(U.dp(this, 6), 0, 0, 0);
        t.addView(name);
        t.addView(spacer());
        IconView s = new IconView(this, IconView.SEARCH, 0xFF0F0F0F);
        s.setOnClickListener(v -> openSearch(true));
        t.addView(s, new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48)));
        IconView m = new IconView(this, IconView.MORE, 0xFF0F0F0F);
        m.setOnClickListener(v -> showSettings());
        t.addView(m, new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48)));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(Color.WHITE);
        box.addView(headerBar(t, 0xFF0F0F0F, 0xFF909090));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        catRow = new LinearLayout(this);
        catRow.setPadding(U.dp(this, 8), U.dp(this, 4), U.dp(this, 8), U.dp(this, 8));
        for (int i = 0; i < CAT_ID.length; i++) {
            final int idx = i;
            TextView c = U.tv(this, CAT_ID[i], 14, 0xFF0F0F0F, false);
            c.setPadding(U.dp(this, 12), U.dp(this, 6), U.dp(this, 12), U.dp(this, 6));
            c.setFocusable(true);
            c.setOnClickListener(v -> selectCat(idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(U.dp(this, 4), 0, U.dp(this, 4), 0);
            catRow.addView(c, lp);
        }
        hs.addView(catRow);
        box.addView(hs);
        styleChips();
        return box;
    }

    private View header2010() {
        LinearLayout t = new LinearLayout(this);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(U.dp(this, 10), 0, U.dp(this, 8), 0);
        t.addView(logoText(Color.WHITE, 20));
        t.addView(spacer());
        IconView s = new IconView(this, IconView.SEARCH, Color.WHITE);
        s.setBackground(U.stroke(0xFF2B2B2B, 0xFF5A5A5A, 6, this));
        s.setOnClickListener(v -> openSearch(true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(U.dp(this, 44), U.dp(this, 36));
        lp.setMargins(U.dp(this, 6), 0, 0, 0);
        t.addView(s, lp);
        IconView m = new IconView(this, IconView.MORE, Color.WHITE);
        m.setBackground(U.stroke(0xFF2B2B2B, 0xFF5A5A5A, 6, this));
        m.setOnClickListener(v -> showSettings());
        t.addView(m, new LinearLayout.LayoutParams(U.dp(this, 44), U.dp(this, 36)));

        View bar = headerBar(t, Color.WHITE, 0xFF9A9A9A);
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF4A4A4A, 0xFF141414}));
        return bar;
    }

    private View headerRetro() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setBackgroundColor(Color.WHITE);
        h.setPadding(U.dp(this, 12), U.dp(this, 8), U.dp(this, 12), 0);

        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        r1.addView(logoText(Color.BLACK, 28));
        TextView tag = U.tv(this, "Broadcast Yourself", 11, 0xFF666666, true);
        tag.setPadding(U.dp(this, 8), U.dp(this, 10), 0, 0);
        r1.addView(tag);
        r1.addView(spacer());
        TextView set = U.tv(this, "Settings", 13, 0xFF0033CC, true);
        set.setPaintFlags(set.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        set.setPadding(U.dp(this, 8), U.dp(this, 6), U.dp(this, 8), U.dp(this, 6));
        set.setFocusable(true);
        set.setOnClickListener(v -> showSettings());
        r1.addView(set);
        h.addView(r1);

        LinearLayout r2 = new LinearLayout(this);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        r2.setPadding(0, U.dp(this, 8), 0, U.dp(this, 8));
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(14);
        searchBox.setTextColor(Color.BLACK);
        searchBox.setBackground(U.stroke(Color.WHITE, 0xFF999999, 0, this));
        searchBox.setPadding(U.dp(this, 6), 0, U.dp(this, 6), 0);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setOnEditorActionListener((v, a, e) -> { doSearch(v.getText().toString()); return true; });
        r2.addView(searchBox, new LinearLayout.LayoutParams(0, U.dp(this, 36), 1f));
        TextView scope = U.tv(this, "Videos", 13, Color.BLACK, false);
        scope.setGravity(Gravity.CENTER);
        scope.setBackground(U.stroke(Color.WHITE, 0xFF999999, 0, this));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(U.dp(this, 80), U.dp(this, 36));
        sl.setMargins(U.dp(this, 6), 0, U.dp(this, 6), 0);
        r2.addView(scope, sl);
        TextView go = U.tv(this, "Search", 13, Color.BLACK, false);
        go.setGravity(Gravity.CENTER);
        go.setFocusable(true);
        go.setBackground(U.stroke(0xFFE4E4E4, 0xFF777777, 3, this));
        go.setOnClickListener(v -> doSearch(searchBox.getText().toString()));
        r2.addView(go, new LinearLayout.LayoutParams(U.dp(this, 80), U.dp(this, 36)));
        h.addView(r2);

        LinearLayout tabs = new LinearLayout(this);
        String[] names = {"Home", "Videos", "Channels", "Community"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean sel = i == 1;
            TextView t = U.tv(this, names[i], 14, sel ? Color.BLACK : 0xFF0033CC, true);
            t.setGravity(Gravity.CENTER);
            t.setFocusable(true);
            t.setPadding(U.dp(this, 18), U.dp(this, 6), U.dp(this, 18), U.dp(this, 6));
            float r = U.dp(this, 8);
            GradientDrawable g = new GradientDrawable();
            g.setColor(sel ? 0xFFE6E6E6 : 0xFFBFD0F0);
            g.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
            t.setBackground(g);
            t.setOnClickListener(v -> {
                if (idx <= 1) selectCat(0);
                else Toast.makeText(this, "Belum tersedia di mode nostalgia", Toast.LENGTH_SHORT).show();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(0, 0, U.dp(this, 3), 0);
            tabs.addView(t, lp);
        }
        h.addView(tabs);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(0xFFE6E6E6);
        catRow = new LinearLayout(this);
        catRow.setPadding(U.dp(this, 6), U.dp(this, 4), U.dp(this, 6), U.dp(this, 4));
        for (int i = 0; i < CAT_EN.length; i++) {
            final int idx = i;
            TextView c = U.tv(this, CAT_EN[i], 13, 0xFF0033CC, false);
            c.setPadding(U.dp(this, 10), U.dp(this, 4), U.dp(this, 10), U.dp(this, 4));
            c.setFocusable(true);
            c.setOnClickListener(v -> selectCat(idx));
            catRow.addView(c);
        }
        hs.addView(catRow);
        h.addView(hs);
        styleChips();
        return h;
    }

    private void styleChips() {
        if (catRow == null) return;
        for (int i = 0; i < catRow.getChildCount(); i++) {
            TextView t = (TextView) catRow.getChildAt(i);
            boolean sel = i == catIndex && query == null;
            if (mode == Prefs.RETRO2008) {
                t.setTextColor(sel ? Color.BLACK : 0xFF0033CC);
                t.setTypeface(null, sel ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
                if (sel) t.setPaintFlags(t.getPaintFlags() & ~Paint.UNDERLINE_TEXT_FLAG);
                else t.setPaintFlags(t.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            } else {
                t.setBackground(U.rect(sel ? 0xFF0F0F0F : 0xFFF2F2F2, 8, this));
                t.setTextColor(sel ? Color.WHITE : 0xFF0F0F0F);
            }
        }
    }

    // ================= Aksi =================

    private void selectCat(int idx) {
        catIndex = idx;
        query = null;
        if (searchBox != null) searchBox.setText("");
        styleChips();
        load();
    }

    private void openSearch(boolean open) {
        if (titleGroup == null || searchGroup == null) return;
        titleGroup.setVisibility(open ? View.GONE : View.VISIBLE);
        searchGroup.setVisibility(open ? View.VISIBLE : View.GONE);
        if (open) {
            searchBox.requestFocus();
            InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (m != null) m.showSoftInput(searchBox, InputMethodManager.SHOW_IMPLICIT);
        } else {
            hideKb();
        }
    }

    private void hideKb() {
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View f = getCurrentFocus();
        if (m != null && f != null) m.hideSoftInputFromWindow(f.getWindowToken(), 0);
    }

    private void doSearch(String q) {
        q = q.trim();
        if (q.length() == 0) return;
        query = q;
        hideKb();
        styleChips();
        load();
    }

    private void showMsg(String s) {
        bar.setVisibility(View.GONE);
        msg.setText(s);
        msg.setVisibility(View.VISIBLE);
    }

    private void load() {
        final String key = p.apiKey();
        if (key.length() == 0) {
            showMsg("Masukkan API key YouTube Data API v3 di Pengaturan.");
            return;
        }
        final String q = query, region = p.region(), code = CAT_CODE[catIndex];
        final String ck = q + "|" + code + "|" + region;
        if (ck.equals(cacheKey) && cacheList != null) {
            show(cacheList);
            return;
        }
        final int id = ++loadId;
        bar.setVisibility(View.VISIBLE);
        msg.setVisibility(View.GONE);
        grid.setAdapter(null);
        Http.<List<Video>>async(() -> q == null ? Api.popular(key, region, code) : Api.search(key, q, region),
                (r, e) -> {
                    if (id != loadId) return;
                    bar.setVisibility(View.GONE);
                    if (e != null) {
                        showMsg("Gagal memuat.\n" + e.getMessage());
                        return;
                    }
                    cacheKey = ck;
                    cacheList = r;
                    show(r);
                });
    }

    private void show(List<Video> r) {
        bar.setVisibility(View.GONE);
        grid.setAdapter(new VideoAdapter(this, r, kind, itemW, padH, query == null ? CAT_EN[catIndex] : "Search results"));
        if (r.isEmpty()) showMsg("Tidak ada video ditemukan.");
        else msg.setVisibility(View.GONE);
        if (panelTitle != null) {
            panelTitle.setText(query == null ? CAT_EN[catIndex] : "Search results for \"" + query + "\"");
            panelCount.setText("Videos 1-" + r.size());
        }
        styleChips();
    }

    private void showSettings() {
        ScrollView sv = new ScrollView(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(U.dp(this, 20), U.dp(this, 12), U.dp(this, 20), U.dp(this, 8));
        sv.addView(l);

        l.addView(U.tv(this, "API key (YouTube Data API v3)", 14, 0xFF000000, true));
        final EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setHint("AIza...");
        key.setText(p.apiKey());
        l.addView(key);
        l.addView(U.tv(this, "Buat di console.cloud.google.com: aktifkan YouTube Data API v3, lalu Credentials > Create API key.",
                12, 0xFF666666, false));

        TextView rl = U.tv(this, "Kode negara (contoh: ID, US, JP)", 14, 0xFF000000, true);
        rl.setPadding(0, U.dp(this, 14), 0, 0);
        l.addView(rl);
        final EditText reg = new EditText(this);
        reg.setSingleLine(true);
        reg.setText(p.region());
        l.addView(reg);

        TextView ml = U.tv(this, "Tampilan", 14, 0xFF000000, true);
        ml.setPadding(0, U.dp(this, 14), 0, 0);
        l.addView(ml);
        final RadioGroup rg = new RadioGroup(this);
        String[] names = {"Modern (mirip YouTube sekarang)", "Nostalgia 2008 desktop (tablet & Android TV)", "Nostalgia 2010 mobile (latar gelap)"};
        for (int m = 0; m < 3; m++) {
            if (m == Prefs.RETRO2008 && !U.retroAllowed(this)) continue;
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + m);
            rb.setText(names[m]);
            rg.addView(rb);
            if (m == mode) rg.check(1000 + m);
        }
        l.addView(rg);

        new AlertDialog.Builder(this)
                .setTitle("Pengaturan")
                .setView(sv)
                .setPositiveButton("Simpan", (d, w) -> {
                    p.setApiKey(key.getText().toString());
                    String r = reg.getText().toString().trim().toUpperCase(Locale.US);
                    p.setRegion(r.length() == 2 ? r : "ID");
                    int cid = rg.getCheckedRadioButtonId();
                    int nm = cid >= 1000 ? cid - 1000 : mode;
                    boolean changed = nm != mode;
                    p.setMode(nm);
                    cacheKey = null;
                    if (changed) recreate();
                    else load();
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    @Override public boolean onKeyUp(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showSettings();
            return true;
        }
        return super.onKeyUp(keyCode, e);
    }

    @Override public void onBackPressed() {
        if (query != null) {
            query = null;
            if (searchBox != null) searchBox.setText("");
            if (searchGroup != null && searchGroup.getVisibility() == View.VISIBLE) openSearch(false);
            styleChips();
            load();
            return;
        }
        if (searchGroup != null && searchGroup.getVisibility() == View.VISIBLE) {
            openSearch(false);
            return;
        }
        super.onBackPressed();
    }
}
