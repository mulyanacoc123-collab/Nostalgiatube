package com.nostalgiatube;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/** KitKat (API 19) punya TLS 1.2 tetapi tidak aktif secara default; kelas ini mengaktifkannya. */
final class Tls12 extends SSLSocketFactory {
    private static Tls12 instance;
    private final SSLSocketFactory d;

    private Tls12(SSLSocketFactory d) { this.d = d; }

    static synchronized Tls12 get() {
        if (instance == null) {
            try {
                SSLContext ctx = SSLContext.getInstance("TLSv1.2");
                ctx.init(null, null, null);
                instance = new Tls12(ctx.getSocketFactory());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return instance;
    }

    private Socket fix(Socket s) {
        if (s instanceof SSLSocket) {
            ((SSLSocket) s).setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
        }
        return s;
    }

    @Override public String[] getDefaultCipherSuites() { return d.getDefaultCipherSuites(); }
    @Override public String[] getSupportedCipherSuites() { return d.getSupportedCipherSuites(); }
    @Override public Socket createSocket(Socket s, String h, int p, boolean a) throws IOException { return fix(d.createSocket(s, h, p, a)); }
    @Override public Socket createSocket(String h, int p) throws IOException { return fix(d.createSocket(h, p)); }
    @Override public Socket createSocket(String h, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(h, p, la, lp)); }
    @Override public Socket createSocket(InetAddress h, int p) throws IOException { return fix(d.createSocket(h, p)); }
    @Override public Socket createSocket(InetAddress h, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(h, p, la, lp)); }
}
