package com.nostalgiatube;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class ImageLoader {
    private ImageLoader() {}

    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) (Runtime.getRuntime().maxMemory() / 8 / 1024)) {
                @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount() / 1024; }
            };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static void load(final ImageView iv, final String url) {
        iv.setTag(url);
        Bitmap b = (url == null || url.length() == 0) ? null : CACHE.get(url);
        if (b != null) { iv.setImageBitmap(b); return; }
        iv.setImageDrawable(new ColorDrawable(0xFF9E9E9E));
        if (url == null || url.length() == 0) return;
        POOL.execute(new Runnable() {
            @Override public void run() {
                try {
                    byte[] d = Http.getBytes(url);
                    final Bitmap bm = BitmapFactory.decodeByteArray(d, 0, d.length);
                    if (bm == null) return;
                    CACHE.put(url, bm);
                    MAIN.post(new Runnable() {
                        @Override public void run() {
                            if (url.equals(iv.getTag())) iv.setImageBitmap(bm);
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        });
    }
}
