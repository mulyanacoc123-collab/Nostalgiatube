package com.nostalgiatube;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private WebView wv;
    private WebChromeClient chrome;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private final List<Video> related = new ArrayList<Video>();
    private VideoAdapter relAdapter;

    static void open(Context c, Video v) {
        Intent i = new Intent(c, PlayerActivity.class);
        i.putExtra("id", v.id);
        i.putExtra("title", v.title);
        i.putExtra("channel", v.channel);
        i.putExtra("desc", v.desc.length() > 3000 ? v.desc.substring(0, 3000) : v.desc);
        i.putExtra("views", v.views);
        i.putExtra("pub", v.published);
        c.startActivity(i);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final int mode = Prefs.effectiveMode(this);
        final Intent in = getIntent();
        final String id = in.getStringExtra("id");
        final String title = in.getStringExtra("title") == null ? "" : in.getStringExtra("title");
        final String channel = in.getStringExtra("channel") == null ? "" : in.getStringExtra("channel");
        final String desc = in.getStringExtra("desc") == null ? "" : in.getStringExtra("desc");
        final long views = in.getLongExtra("views", 0), pub = in.getLongExtra("pub", 0);

        boolean dark = mode == Prefs.MOBILE2010;
        int bg = dark ? Color.BLACK : Color.WHITE;
        int fg = dark ? Color.WHITE : 0xFF0F0F0F;
        int sub = dark ? 0xFFAAAAAA : 0xFF606060;
        boolean wide = U.screenDp(this) >= 600;
        int sw = U.widthPx(this);
        int pw = wide ? sw * 3 / 5 : sw;
        int ph = pw * 9 / 16;

        // ---- pemutar ----
        FrameLayout web = new FrameLayout(this);
        web.setBackgroundColor(Color.BLACK);
        wv = new WebView(this);
        web.addView(wv, new FrameLayout.LayoutParams(MATCH, MATCH));
        setupWeb(id);

        // ---- info video ----
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setBackgroundColor(bg);
        info.setPadding(U.dp(this, 12), U.dp(this, 12), U.dp(this, 12), U.dp(this, 8));

        TextView t = U.tv(this, title, mode == Prefs.RETRO2008 ? 20 : 18, fg, true);
        info.addView(t);
        TextView meta = U.tv(this, "", 13, sub, false);
        meta.setPadding(0, U.dp(this, 4), 0, 0);
        String ch = TextUtils.htmlEncode(channel);
        if (mode == Prefs.RETRO2008) {
            meta.setText(Html.fromHtml("<font color='#666666'>From:</font> <b><font color='#0033CC'>" + ch
                    + "</font></b> &nbsp;&nbsp; <font color='#666666'>Added:</font> " + Fmt.ago(pub, true)
                    + " &nbsp;&nbsp; <font color='#666666'>Views:</font> " + Fmt.full(views)));
        } else if (mode == Prefs.MOBILE2010) {
            meta.setText("by " + channel + "\n" + Fmt.full(views) + " views");
        } else {
            meta.setText(Fmt.compact(views) + " x ditonton \u2022 " + Fmt.ago(pub, false) + "\n" + channel);
        }
        info.addView(meta);

        TextView open = U.tv(this, "Buka di aplikasi / peramban lain", 13, mode == Prefs.RETRO2008 ? 0xFF0033CC : 0xFFCC0000, true);
        open.setPadding(0, U.dp(this, 10), 0, U.dp(this, 4));
        open.setFocusable(true);
        open.setOnClickListener(v -> {
            try {
                startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/watch?v=" + id)), null));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Tidak ada aplikasi yang bisa membuka tautan", Toast.LENGTH_SHORT).show();
            }
        });
        info.addView(open);
        TextView hint = U.tv(this, "Jika pemutar kosong/error: perbarui \"Android System WebView\" atau gunakan tombol di atas.", 11, sub, false);
        info.addView(hint);

        if (desc.length() > 0) {
            final TextView d = U.tv(this, desc, 13, sub, false);
            d.setPadding(0, U.dp(this, 10), 0, 0);
            d.setMaxLines(4);
            d.setEllipsize(TextUtils.TruncateAt.END);
            d.setOnClickListener(v -> {
                boolean collapsed = d.getMaxLines() == 4;
                d.setMaxLines(collapsed ? 1000 : 4);
            });
            info.addView(d);
        }

        // ---- daftar terkait ----
        String relText = mode == Prefs.RETRO2008 ? "Related Videos" : mode == Prefs.MOBILE2010 ? "Related videos" : "Video terkait";
        TextView relLabel = U.tv(this, relText, 14, fg, true);
        relLabel.setBackgroundColor(bg);
        relLabel.setPadding(U.dp(this, 12), U.dp(this, 10), U.dp(this, 12), U.dp(this, 6));

        int relKind = mode == Prefs.RETRO2008 ? VideoAdapter.ROW2008
                : mode == Prefs.MOBILE2010 ? VideoAdapter.ROW2010
                : (wide ? VideoAdapter.ROWMOD : VideoAdapter.CARD);
        int relW = wide ? sw * 2 / 5 : sw;
        relAdapter = new VideoAdapter(this, related, relKind, relW, 0, "Related");

        final ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setDividerHeight(0);
        lv.setCacheColorHint(0);
        lv.setBackgroundColor(bg);
        if (!wide) lv.addHeaderView(info, null, false);
        lv.addHeaderView(relLabel, null, false);
        lv.setAdapter(relAdapter);
        lv.setOnItemClickListener((a, v, pos, rid) -> {
            Object o = a.getItemAtPosition(pos);
            if (o instanceof Video) open(PlayerActivity.this, (Video) o);
        });

        // ---- susunan layar ----
        LinearLayout root = new LinearLayout(this);
        root.setBackgroundColor(bg);
        if (!wide) {
            root.setOrientation(LinearLayout.VERTICAL);
            root.addView(web, new LinearLayout.LayoutParams(MATCH, ph));
            root.addView(lv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        } else {
            root.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout left = new LinearLayout(this);
            left.setOrientation(LinearLayout.VERTICAL);
            left.addView(web, new LinearLayout.LayoutParams(MATCH, ph));
            ScrollView sc = new ScrollView(this);
            sc.addView(info);
            left.addView(sc, new LinearLayout.LayoutParams(MATCH, 0, 1f));
            root.addView(left, new LinearLayout.LayoutParams(0, MATCH, 3f));
            root.addView(lv, new LinearLayout.LayoutParams(0, MATCH, 2f));
        }
        setContentView(root);

        // ---- ambil video terkait (pencarian berdasarkan judul) ----
        Prefs p = new Prefs(this);
        final String key = p.apiKey(), region = p.region();
        if (key.length() > 0) {
            Http.<List<Video>>async(() -> Api.search(key, title, region), (r, e) -> {
                if (isFinishing() || e != null || r == null) return;
                related.clear();
                for (Video v : r) if (!v.id.equals(id)) related.add(v);
                relAdapter.notifyDataSetChanged();
            });
        }
    }

    private void setupWeb(String id) {
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(Color.BLACK);
        wv.setWebViewClient(new WebViewClient());
        chrome = new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                ((FrameLayout) getWindow().getDecorView()).addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }

            @Override public void onHideCustomView() {
                if (customView == null) return;
                ((FrameLayout) getWindow().getDecorView()).removeView(customView);
                customView = null;
                if (customCb != null) customCb.onCustomViewHidden();
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            }
        };
        wv.setWebChromeClient(chrome);
        String html = "<html><body style='margin:0;background:#000'>"
                + "<iframe src='https://www.youtube.com/embed/" + id
                + "?autoplay=1&playsinline=1&rel=0&fs=1&origin=https://www.youtube.com' frameborder='0' "
                + "allow='autoplay; fullscreen; encrypted-media' allowfullscreen "
                + "style='position:absolute;top:0;left:0;width:100%;height:100%'></iframe></body></html>";
        wv.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "utf-8", null);
    }

    @Override public void onBackPressed() {
        if (customView != null) { chrome.onHideCustomView(); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() {
        super.onPause();
        if (wv != null) wv.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (wv != null) wv.onResume();
    }

    @Override protected void onDestroy() {
        if (wv != null) {
            ViewGroup parent = (ViewGroup) wv.getParent();
            if (parent != null) parent.removeView(wv);
            wv.destroy();
            wv = null;
        }
        super.onDestroy();
    }
}
